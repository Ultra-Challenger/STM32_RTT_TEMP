#ifndef __USART_H__
#define __USART_H__

#include <rthw.h>
#include <rtthread.h>
#include "stm32f10x.h"

int rt_hw_usart_init(void);

#endif
