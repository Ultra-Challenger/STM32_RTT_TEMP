#ifndef __DRV_USART_H__
#define __DRV_USART_H__

#include <rthw.h>
#include <rtthread.h>
#include "stm32f4xx.h"

int rt_hw_usart_init(void);

#endif
